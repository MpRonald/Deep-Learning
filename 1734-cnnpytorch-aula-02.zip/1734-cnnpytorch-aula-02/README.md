# 1734-cnnpytorch
Conteúdo prático do curso online Redes Neurais Convolucionais: Deep Learning com PyTorch da Alura.
